﻿using Xamarin.Forms;

namespace VisualProvision.Pages
{
    public partial class MediaPage
    {
        public MediaPage()
        {
            InitializeComponent();
            ApplyTemplate();
        }
    }
}
