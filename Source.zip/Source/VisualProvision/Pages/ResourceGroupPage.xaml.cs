﻿using Xamarin.Forms;

namespace VisualProvision.Pages
{
    public partial class ResourceGroupPage
    {
        public ResourceGroupPage()
        {
            InitializeComponent();
            ApplyTemplate();
        }
    }
}