﻿namespace VisualProvision.Pages
{
    public partial class SubscriptionPage
    {
        public SubscriptionPage()
        {
            InitializeComponent();
            ApplyTemplate();
        }

        protected override void OnSizeAllocated(double width, double height)
        {
            base.OnSizeAllocated(width, height);
        }
    }
}