﻿using Xamarin.Forms;

namespace VisualProvision.Pages
{
    public partial class ServicesPage
    {
        public ServicesPage()
        {
            InitializeComponent();
            ApplyTemplate();
        }
    }
}
