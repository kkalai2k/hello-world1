﻿using Xamarin.Forms;

namespace VisualProvision.Pages
{
    public partial class LoginPage
    {
        public LoginPage()
        {
            ShowLogout = false;

            InitializeComponent();
            ApplyTemplate();
        }
    }
}