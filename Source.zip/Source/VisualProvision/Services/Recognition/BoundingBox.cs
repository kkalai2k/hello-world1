﻿namespace VisualProvision.Services.Recognition
{
    public class BoundingBox
    {
        public double Left { get; set; }

        public double Top { get; set; }

        public double Width { get; set; }

        public double Height { get; set; }
    }
}
