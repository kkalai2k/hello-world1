﻿namespace VisualProvision.Models
{
    public class ResourceGroup
    {
        public bool Selected { get; set; }

        public string Name { get; set; }
    }
}