﻿using Microsoft.Azure.Management.ResourceManager.Fluent.Core;

namespace VisualProvision.Models
{
    public class Ubication
    {
        public string Name { get; set; }

        public Region Region { get; set; }
    }
}