﻿namespace VisualProvision.Models
{
    public class Subscription
    {
        public string SubscriptionId { get; set; }

        public string DisplayName { get; set; }
    }
}
