﻿using Xamarin.Forms;

namespace VisualProvision.Resources
{
    public partial class Common : ResourceDictionary
    {
        public Common()
        {
            InitializeComponent();
        }
    }
}