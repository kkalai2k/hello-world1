﻿using Xamarin.Forms;

namespace VisualProvision.Resources
{
    public partial class Fonts : ResourceDictionary
    {
        public Fonts()
        {
            InitializeComponent();
        }
    }
}