﻿using Xamarin.Forms;

namespace VisualProvision.Resources
{
    public partial class Colors : ResourceDictionary
    {
        public Colors()
        {
            InitializeComponent();
        }
    }
}