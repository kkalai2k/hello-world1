﻿using Xamarin.Forms;

namespace VisualProvision.Resources
{
    public partial class Converters : ResourceDictionary
    {
        public Converters()
        {
            InitializeComponent();
        }
    }
}