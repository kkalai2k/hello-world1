﻿using Xamarin.Forms;

namespace VisualProvision.Templates
{
    public partial class ResourceGroupItemTemplate : ContentView
    {
        public ResourceGroupItemTemplate()
        {
            InitializeComponent();
        }
    }
}
