﻿using Xamarin.Forms;

namespace VisualProvision.Templates
{
    public partial class ServiceItemTemplate : ContentView
    {
        public ServiceItemTemplate()
        {
            InitializeComponent();
        }
    }
}