﻿using Xamarin.Forms;

namespace VisualProvision.Templates
{
    public partial class ResultItemTemplate : ContentView
    {
        public ResultItemTemplate()
        {
            InitializeComponent();
        }
    }
}