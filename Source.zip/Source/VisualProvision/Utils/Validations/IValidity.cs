﻿namespace VisualProvision.Utils.Validations
{
    public interface IValidity
    {
        bool IsValid { get; set; }
    }
}
